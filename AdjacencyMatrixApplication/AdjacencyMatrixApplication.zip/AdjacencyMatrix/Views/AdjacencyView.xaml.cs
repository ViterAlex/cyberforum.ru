﻿using System.Windows.Controls;

namespace AdjacencyMatrix.Views
{
    /// <summary>
    /// Interaction logic for AdjacencyView.xaml
    /// </summary>
    public partial class AdjacencyView : UserControl
    {
        public AdjacencyView()
        {
            InitializeComponent();
        }
    }
}
