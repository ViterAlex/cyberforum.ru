﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CSVProcessingNamespace {
	public partial class MainForm : Form {
		CSVProcess cp;////Класс, обрабатывающий CSV-файл 
		RowsColumnsSelectForm f2;//вторая форма для выбора строк и столбцов
		public MainForm() {
			InitializeComponent();
		}

		private void OpenFileButton_Click(object sender, EventArgs e) {
			if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
				if (cp != null) { cp.Dispose(); cp = null; }
				if (f2 != null) { f2.Close(); f2 = null; }
				cp = new CSVProcess(openFileDialog1.FileName);
				f2 = new RowsColumnsSelectForm(cp);
				f2.Show();
			}
		}
	}
}
